.code 
    LOAD limite 
loop: 
    SUB #1          # Decrementa o acumulador (acc = acc - 1) 
    STORE temp      # Salva o contador atual em memória 
    SYSCALL 1       # Imprime acc e BLOQUEIA por 3 UTs (força retorno à Fila 0) 
    LOAD temp       # Recupera o contador para a próxima iteração 
    BRPOS loop      # Enquanto acc > 0, continua no laço 
    SYSCALL 0       # Encerra o processo (HALT) 
.endcode 
 
.data 
    limite 3 
    temp 0 
.enddata